const mongoose = require("mongoose");
const initData = require("./data.js");
const Listing = require("../models/listing.js");

const dbUrl = "mongodb://127.0.0.1:27017/offlineDiamond";

async function connectToDB() {
  try {
    await mongoose.connect(dbUrl);
    console.log("Connected to MongoDB");
    
    await initDB(); // ✅ Call initDB() only after successful connection
    mongoose.connection.close(); // ✅ Close connection after operation
  } catch (err) {
    console.error("Error connecting to MongoDB:", err);
  }
}

const initDB = async () => {
  try {
    await Listing.deleteMany({});
    await Listing.insertMany(initData.data);
    console.log("Data was initialized");
  } catch (err) {
    console.error("Error inserting data:", err);
  }
};

// Run the script
connectToDB();
