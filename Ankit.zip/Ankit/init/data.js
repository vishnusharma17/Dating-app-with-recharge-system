const sampleData = [
    {
        diamond: 1060,
        price: 75,
        extra: 6,
    },
    {
        diamond: 1413,
        price: 100,
        extra: 6,
    },
    {
        diamond: 2827,
        price: 200,
        extra: 6,
    },

    {
        diamond: 4947,
        price: 350,
        extra: 6,
    },

    {
        diamond: 7067,
        price: 500,
        extra: 6,
    },

    {
        diamond: 10600,
        price: 750,
        extra: 6,
    },

    {
        diamond: 14133,
        price: 1000,
        extra: 6,
    },

    {
        diamond: 1060,
        price: 4000,
        extra: 7,
    },
    {
        diamond: 50000,
        price: 4800,
        extra: 7,
    },
    {
        diamond: 57860,
        price: 5400,
        extra: 7,
    },
    {
        diamond: 55860,
        price: 5200,
        extra: 7,
    },
    {
        diamond: 55860,
        price: 5500,
        extra: 7,
    },

    {
        diamond: 129600,
        price: 8400,
        extra: 8,
    },

    {
        diamond: 128600,
        price: 8200,
        extra: 8,
    },

    {
        diamond: 129400,
        price: 8600,
        extra: 8,
    },

    {
        diamond: 127500,
        price: 8900,
        extra: 8,
    },

    {
        diamond: 121600,
        price: 7400,
        extra: 8,
    },

    {
        diamond: 160000,
        price: 13000,
        extra: 12,
    },

    {
        diamond: 240000,
        price: 15000,
        extra: 12,
    },

    {
        diamond: 408800,
        price: 25100,
        extra: 12,
    },
];

module.exports = { data: sampleData };